"use client";

import { useCallback } from "react";
import { Textarea } from "@/components/ui/textarea";

interface JournalEditorProps {
  content: string;
  onChange: (value: string) => void;
}

export function JournalEditor({ content, onChange }: JournalEditorProps) {
  const handleChange = useCallback(
    (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      onChange(e.target.value);
    },
    [onChange]
  );

  return (
    <Textarea
      value={content}
      onChange={handleChange}
      placeholder="Begin your reflection here..."
      className="min-h-[calc(100vh-12rem)] resize-none border-none focus-visible:ring-0"
    />
  );
}
"use client";

import { PenLine, Calendar, Compass, BookOpen, Target } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ModeToggle } from "@/components/mode-toggle";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

export default function Header() {
  const pathname = usePathname();
  
  const navigation = [
    { name: "Today", href: "/", icon: Calendar },
    { name: "Planning", href: "/planning", icon: Target },
    { name: "Explore", href: "/explore", icon: Compass },
    { name: "Entries", href: "/entries", icon: BookOpen },
  ];

  return (
    <header className="border-b">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center space-x-8">
          <Link href="/" className="flex items-center space-x-2">
            <PenLine className="h-6 w-6 text-primary" />
            <span className="font-semibold text-xl">Stoic Journal</span>
          </Link>
          <nav className="hidden md:flex items-center space-x-4">
            {navigation.map((item) => {
              const Icon = item.icon;
              return (
                <Link
                  key={item.name}
                  href={item.href}
                  className={cn(
                    "flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors",
                    pathname === item.href
                      ? "bg-secondary text-secondary-foreground"
                      : "hover:bg-secondary/80"
                  )}
                >
                  <Icon className="h-4 w-4" />
                  <span>{item.name}</span>
                </Link>
              );
            })}
          </nav>
        </div>
        <div className="flex items-center space-x-4">
          <ModeToggle />
          <Button asChild>
            <Link href="/journal/morning">
              <PenLine className="mr-2 h-4 w-4" /> Write
            </Link>
          </Button>
        </div>
      </div>
    </header>
  );
}
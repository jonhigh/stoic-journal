import { Card } from "@/components/ui/card";

const stats = [
  { label: "Streak", value: "0" },
  { label: "Entries", value: "0" },
  { label: "Words", value: "0" },
];

export function StatsOverview() {
  return (
    <div className="grid md:grid-cols-3 gap-4">
      {stats.map((stat) => (
        <Card key={stat.label} className="p-6">
          <h3 className="text-sm font-medium text-muted-foreground">{stat.label}</h3>
          <p className="text-2xl font-bold mt-2">{stat.value}</p>
        </Card>
      ))}
    </div>
  );
}
"use client";

import { Card } from "@/components/ui/card";
import { Quote } from "lucide-react";

export function DailyQuote() {
  return (
    <Card className="p-6">
      <div className="flex items-start gap-4">
        <Quote className="h-6 w-6 text-primary shrink-0" />
        <div>
          <blockquote className="text-lg font-medium">
            "Waste no more time arguing what a good man should be. Be one."
          </blockquote>
          <footer className="text-sm text-muted-foreground mt-2">
            — Marcus Aurelius, Meditations
          </footer>
        </div>
      </div>
    </Card>
  );
}
"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sun, Moon, ChevronRight } from "lucide-react";
import Link from "next/link";

interface JournalEntry {
  id: string;
  type: "morning" | "evening";
  date: Date;
  content: string;
  preview: string;
}

interface JournalEntryCardProps {
  entry: JournalEntry;
}

export function JournalEntryCard({ entry }: JournalEntryCardProps) {
  const Icon = entry.type === "morning" ? Sun : Moon;
  const iconColor = entry.type === "morning" ? "text-yellow-500" : "text-blue-500";
  
  return (
    <Card className="p-6">
      <div className="flex items-start justify-between">
        <div className="flex items-start gap-4">
          <Icon className={`h-5 w-5 mt-1 ${iconColor}`} />
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-semibold capitalize">
                {entry.type} Reflection
              </h3>
              <span className="text-sm text-muted-foreground">
                {entry.date.toLocaleDateString("en-US", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </span>
            </div>
            <p className="mt-2 text-muted-foreground line-clamp-2">
              {entry.preview}
            </p>
          </div>
        </div>
        <Button variant="ghost" size="icon" asChild>
          <Link href={`/entries/${entry.id}`}>
            <ChevronRight className="h-4 w-4" />
          </Link>
        </Button>
      </div>
    </Card>
  );
}
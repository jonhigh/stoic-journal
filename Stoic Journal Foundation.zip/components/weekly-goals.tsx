"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Target, 
  Plus,
  CheckCircle2,
  Circle
} from "lucide-react";

export function WeeklyGoals() {
  const goals = [
    { text: "Complete 7 daily journals", completed: false },
    { text: "Practice virtue of Justice in daily interactions", completed: true },
    { text: "Read 3 chapters of Stoic philosophy", completed: false },
    { text: "Meditate for 10 minutes daily", completed: true },
  ];

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Target className="h-5 w-5 text-primary" />
          <h2 className="text-xl font-semibold">Weekly Goals</h2>
        </div>
        <Button variant="ghost" size="icon">
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      <ul className="space-y-3">
        {goals.map((goal, index) => (
          <li key={index} className="flex items-start gap-3">
            {goal.completed ? (
              <CheckCircle2 className="h-5 w-5 text-primary shrink-0" />
            ) : (
              <Circle className="h-5 w-5 text-muted-foreground shrink-0" />
            )}
            <span className="text-sm">{goal.text}</span>
          </li>
        ))}
      </ul>
    </Card>
  );
}
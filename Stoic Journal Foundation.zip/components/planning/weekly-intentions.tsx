"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Target, Plus, X } from "lucide-react";
import { useState } from "react";

export function WeeklyIntentions() {
  const [intentions, setIntentions] = useState([
    "Practice daily meditation for inner tranquility",
    "Apply wisdom before reacting to challenges",
    "Show kindness in every interaction",
  ]);
  const [newIntention, setNewIntention] = useState("");

  const addIntention = () => {
    if (newIntention.trim()) {
      setIntentions([...intentions, newIntention.trim()]);
      setNewIntention("");
    }
  };

  const removeIntention = (index: number) => {
    setIntentions(intentions.filter((_, i) => i !== index));
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Target className="h-5 w-5 text-primary" />
          <h2 className="text-xl font-semibold">Weekly Intentions</h2>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder="Add a new intention..."
            value={newIntention}
            onChange={(e) => setNewIntention(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && addIntention()}
          />
          <Button onClick={addIntention} size="icon">
            <Plus className="h-4 w-4" />
          </Button>
        </div>

        <Separator />

        <ul className="space-y-3">
          {intentions.map((intention, index) => (
            <li key={index} className="flex items-center justify-between gap-2 group">
              <span className="text-sm">{intention}</span>
              <Button
                variant="ghost"
                size="icon"
                className="opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => removeIntention(index)}
              >
                <X className="h-4 w-4" />
              </Button>
            </li>
          ))}
        </ul>
      </div>
    </Card>
  );
}
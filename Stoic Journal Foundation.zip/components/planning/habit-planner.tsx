"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { Activity, Plus, X } from "lucide-react";
import { useState } from "react";

interface Habit {
  id: string;
  text: string;
  completed: boolean;
}

export function HabitPlanner() {
  const [habits, setHabits] = useState<Habit[]>([
    { id: "1", text: "Morning meditation", completed: false },
    { id: "2", text: "Read Stoic philosophy", completed: true },
    { id: "3", text: "Evening reflection", completed: false },
  ]);
  const [newHabit, setNewHabit] = useState("");

  const addHabit = () => {
    if (newHabit.trim()) {
      setHabits([
        ...habits,
        { id: Date.now().toString(), text: newHabit.trim(), completed: false },
      ]);
      setNewHabit("");
    }
  };

  const toggleHabit = (id: string) => {
    setHabits(
      habits.map((habit) =>
        habit.id === id ? { ...habit, completed: !habit.completed } : habit
      )
    );
  };

  const removeHabit = (id: string) => {
    setHabits(habits.filter((habit) => habit.id !== id));
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Activity className="h-5 w-5 text-primary" />
          <h2 className="text-xl font-semibold">Daily Habits</h2>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder="Add a new habit..."
            value={newHabit}
            onChange={(e) => setNewHabit(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && addHabit()}
          />
          <Button onClick={addHabit} size="icon">
            <Plus className="h-4 w-4" />
          </Button>
        </div>

        <Separator />

        <ul className="space-y-3">
          {habits.map((habit) => (
            <li key={habit.id} className="flex items-center justify-between gap-2 group">
              <div className="flex items-center gap-3">
                <Checkbox
                  checked={habit.completed}
                  onCheckedChange={() => toggleHabit(habit.id)}
                />
                <span className="text-sm">{habit.text}</span>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => removeHabit(habit.id)}
              >
                <X className="h-4 w-4" />
              </Button>
            </li>
          ))}
        </ul>
      </div>
    </Card>
  );
}
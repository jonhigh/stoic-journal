"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Checkbox } from "@/components/ui/checkbox";
import { Target, Plus, X, AlertCircle } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/components/ui/use-toast";

export function DailyFocusPriorities() {
  const [priorities, setPriorities] = useState([
    { id: '1', text: "Practice mindful meditation", completed: false },
    { id: '2', text: "Read Stoic philosophy", completed: true },
    { id: '3', text: "Exercise with intention", completed: false },
  ]);
  const [newPriority, setNewPriority] = useState("");
  const { toast } = useToast();

  const addPriority = () => {
    if (newPriority.trim() && priorities.length < 5) {
      const priority = {
        id: Date.now().toString(),
        text: newPriority.trim(),
        completed: false,
      };
      
      setPriorities([...priorities, priority]);
      setNewPriority("");
      
      toast({
        title: "Priority added",
        description: "Your new priority has been saved.",
      });
    }
  };

  const removePriority = (id: string) => {
    setPriorities(priorities.filter((priority) => priority.id !== id));
    toast({
      title: "Priority removed",
      description: "The priority has been deleted.",
    });
  };

  const togglePriority = (id: string) => {
    setPriorities(priorities.map((p) =>
      p.id === id ? { ...p, completed: !p.completed } : p
    ));
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Target className="h-5 w-5 text-primary" />
          <h2 className="text-xl font-semibold">Daily Focus</h2>
        </div>
        <div className="text-sm text-muted-foreground space-x-2">
          <span>{priorities.filter(p => p.completed).length}/{priorities.length} completed</span>
          <span>•</span>
          <span>{priorities.length}/5 priorities</span>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder="Add a new priority..."
            value={newPriority}
            onChange={(e) => setNewPriority(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && addPriority()}
            disabled={priorities.length >= 5}
          />
          <Button 
            onClick={addPriority} 
            size="icon"
            disabled={priorities.length >= 5}
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>

        {priorities.length >= 5 && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <AlertCircle className="h-4 w-4" />
            <span>Maximum 5 priorities allowed</span>
          </div>
        )}

        <Separator />

        <ul className="space-y-3">
          {priorities.map((priority, index) => (
            <li 
              key={priority.id} 
              className="flex items-center justify-between gap-2 group"
            >
              <div className="flex items-start gap-3 min-w-0">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border text-xs">
                  {index + 1}
                </span>
                <div className="flex items-start gap-3 min-w-0 flex-1">
                  <Checkbox
                    checked={priority.completed}
                    onCheckedChange={() => togglePriority(priority.id)}
                    className="mt-1"
                  />
                  <span className={`text-sm flex-1 ${priority.completed ? "line-through text-muted-foreground" : ""}`}>
                    {priority.text}
                  </span>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => removePriority(priority.id)}
              >
                <X className="h-4 w-4" />
              </Button>
            </li>
          ))}
        </ul>
      </div>
    </Card>
  );
}
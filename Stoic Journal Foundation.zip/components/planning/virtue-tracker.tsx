"use client";

import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Shield } from "lucide-react";

const virtues = [
  { name: "Wisdom", progress: 65, description: "Knowledge and good judgment" },
  { name: "Justice", progress: 80, description: "Fairness and moral rightness" },
  { name: "Courage", progress: 45, description: "Facing challenges with fortitude" },
  { name: "Temperance", progress: 70, description: "Self-control and moderation" },
];

export function VirtueTracker() {
  return (
    <Card className="p-6">
      <div className="flex items-center gap-2 mb-6">
        <Shield className="h-5 w-5 text-primary" />
        <h2 className="text-xl font-semibold">Virtue Progress</h2>
      </div>

      <div className="space-y-6">
        {virtues.map((virtue) => (
          <div key={virtue.name} className="space-y-2">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-medium">{virtue.name}</h3>
                <p className="text-sm text-muted-foreground">{virtue.description}</p>
              </div>
              <span className="text-sm font-medium">{virtue.progress}%</span>
            </div>
            <Progress value={virtue.progress} className="h-2" />
          </div>
        ))}
      </div>
    </Card>
  );
}
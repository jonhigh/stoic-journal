import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Moon, Sun, ArrowRight } from "lucide-react";
import Link from "next/link";

export function JournalPrompts() {
  return (
    <div className="grid md:grid-cols-2 gap-6">
      <Card className="p-6 space-y-4">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-xl font-semibold">Morning Reflection</h2>
            <p className="text-muted-foreground mt-1">Start your day with intention</p>
          </div>
          <Sun className="h-6 w-6 text-yellow-500" />
        </div>
        <Button className="w-full" asChild>
          <Link href="/journal/morning">
            Begin Morning Journal <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </Card>

      <Card className="p-6 space-y-4">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-xl font-semibold">Evening Review</h2>
            <p className="text-muted-foreground mt-1">Reflect on your day</p>
          </div>
          <Moon className="h-6 w-6 text-blue-500" />
        </div>
        <Button className="w-full" asChild>
          <Link href="/journal/evening">
            Begin Evening Journal <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </Card>
    </div>
  );
}
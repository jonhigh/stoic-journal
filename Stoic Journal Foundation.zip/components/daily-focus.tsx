"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Target, Plus } from "lucide-react";

export function DailyFocus() {
  const priorities = [
    "Practice mindful meditation for 20 minutes",
    "Read one chapter of Meditations",
    "Write in gratitude journal",
  ];

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Target className="h-5 w-5 text-primary" />
          <h2 className="text-xl font-semibold">Daily Focus</h2>
        </div>
        <Button variant="ghost" size="icon">
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      <ul className="space-y-3">
        {priorities.map((priority, index) => (
          <li key={index} className="flex items-start gap-3">
            <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full border text-xs">
              {index + 1}
            </span>
            <span className="text-sm">{priority}</span>
          </li>
        ))}
      </ul>
    </Card>
  );
}
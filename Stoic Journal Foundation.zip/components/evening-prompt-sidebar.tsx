"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { 
  BookOpen, 
  Sparkles,
  MessageSquare
} from "lucide-react";

interface EveningPromptSidebarProps {
  onPromptClick: (prompt: string) => void;
}

const prompts = [
  {
    category: "Daily Review",
    items: [
      "What were the most meaningful moments of my day?",
      "How did I practice virtue today?",
      "What challenges did I face, and how did I respond?",
    ],
  },
  {
    category: "Self-Examination",
    items: [
      "What could I have done better today?",
      "Did I act according to my values?",
      "How did I treat others today?",
    ],
  },
  {
    category: "Growth & Learning",
    items: [
      "What did I learn about myself today?",
      "How can I improve tomorrow?",
      "What am I grateful for today?",
    ],
  },
  {
    category: "Reflection on Virtues",
    items: [
      "How did I demonstrate wisdom today?",
      "In what ways did I show courage?",
      "How did I practice justice and temperance?",
    ],
  },
];

export function EveningPromptSidebar({ onPromptClick }: EveningPromptSidebarProps) {
  return (
    <Card className="h-full flex flex-col">
      <div className="p-6 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <BookOpen className="h-5 w-5" />
          <h2 className="text-lg font-semibold">Prompts</h2>
        </div>
        <Button variant="ghost" size="icon" className="h-9 w-9">
          <Sparkles className="h-5 w-5" />
        </Button>
      </div>
      <Separator className="shrink-0" />
      <ScrollArea className="flex-1">
        <div className="px-4 py-4">
          {prompts.map((section) => (
            <div key={section.category} className="mb-6 last:mb-0">
              <h3 className="text-sm font-medium text-muted-foreground px-2 mb-2">
                {section.category}
              </h3>
              <div className="space-y-1">
                {section.items.map((prompt, index) => (
                  <Button
                    key={index}
                    variant="ghost"
                    className="w-full justify-start text-sm h-auto whitespace-normal px-2 py-2"
                    onClick={() => onPromptClick(prompt)}
                  >
                    <div className="flex gap-2 min-w-0">
                      <MessageSquare className="h-4 w-4 mt-0.5 text-muted-foreground shrink-0" />
                      <span className="text-left break-words">{prompt}</span>
                    </div>
                  </Button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>
    </Card>
  );
}
"use client";

import { DailyFocusPriorities } from "@/components/planning/daily-focus";
import { VirtueTracker } from "@/components/planning/virtue-tracker";
import { HabitPlanner } from "@/components/planning/habit-planner";
import { WeeklyIntentions } from "@/components/planning/weekly-intentions";
import { PlanningCalendar } from "@/components/planning/calendar";

export default function PlanningPage() {
  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Planning & Intentions</h1>
          <p className="text-muted-foreground mt-1">Set your intentions and plan your practice</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-[1fr,380px] gap-6">
        <div className="space-y-6">
          <DailyFocusPriorities />
          <WeeklyIntentions />
          <HabitPlanner />
        </div>
        <div className="space-y-6">
          <PlanningCalendar />
          <VirtueTracker />
        </div>
      </div>
    </div>
  );
}
import { Card } from "@/components/ui/card";
import { BookOpen, Calendar, Sun, Moon } from "lucide-react";
import { JournalEntryCard } from "@/components/entries/journal-entry-card";

const entries = [
  {
    id: "1",
    type: "morning" as const,
    date: new Date("2024-01-10"),
    content: "Today I will focus on practicing patience in challenging situations...",
    preview: "Today I will focus on practicing patience in challenging situations. My intention is to respond thoughtfully rather than react impulsively..."
  },
  {
    id: "2",
    type: "evening" as const,
    date: new Date("2024-01-10"),
    content: "Reflecting on today's events, I noticed several opportunities...",
    preview: "Reflecting on today's events, I noticed several opportunities to practice virtue. In my morning meeting..."
  },
  {
    id: "3",
    type: "morning" as const,
    date: new Date("2024-01-09"),
    content: "My focus for today is on maintaining equanimity...",
    preview: "My focus for today is on maintaining equanimity in the face of external events. I will remember that..."
  }
];

export default function EntriesPage() {
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Journal Entries</h1>
          <p className="text-muted-foreground mt-1">
            Your collection of daily reflections and insights
          </p>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <Card className="p-6">
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <h3 className="text-sm font-medium text-muted-foreground">Days Journaling</h3>
          </div>
          <p className="text-2xl font-bold mt-2">2</p>
        </Card>
        <Card className="p-6">
          <div className="flex items-center gap-2">
            <Sun className="h-4 w-4 text-muted-foreground" />
            <h3 className="text-sm font-medium text-muted-foreground">Morning Entries</h3>
          </div>
          <p className="text-2xl font-bold mt-2">2</p>
        </Card>
        <Card className="p-6">
          <div className="flex items-center gap-2">
            <Moon className="h-4 w-4 text-muted-foreground" />
            <h3 className="text-sm font-medium text-muted-foreground">Evening Entries</h3>
          </div>
          <p className="text-2xl font-bold mt-2">1</p>
        </Card>
      </div>

      <div className="space-y-4">
        {entries.map((entry) => (
          <JournalEntryCard key={entry.id} entry={entry} />
        ))}
      </div>
    </div>
  );
}
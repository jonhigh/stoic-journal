import { Card } from "@/components/ui/card";
import { BookOpen, ExternalLink } from "lucide-react";

const books = [
  {
    title: "Meditations",
    author: "Marcus Aurelius",
    description: "Personal writings reflecting on life, leadership, and philosophy.",
    link: "https://www.gutenberg.org/ebooks/2680"
  },
  {
    title: "Letters from a Stoic",
    author: "Seneca",
    description: "Moral letters addressing the most important questions in life.",
    link: "https://www.gutenberg.org/ebooks/124"
  },
  {
    title: "Discourses",
    author: "Epictetus",
    description: "Fundamental teachings on Stoic philosophy and practical wisdom.",
    link: "https://www.gutenberg.org/ebooks/1018"
  }
];

export default function ReadingPage() {
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Reading List</h1>
        <p className="text-muted-foreground mt-1">
          Essential texts from Stoic philosophy
        </p>
      </div>

      <div className="space-y-4">
        {books.map((book) => (
          <Card key={book.title} className="p-6">
            <div className="flex items-start gap-4">
              <BookOpen className="h-6 w-6 text-primary shrink-0" />
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold">{book.title}</h2>
                  <a
                    href={book.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-primary hover:text-primary/80"
                  >
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  by {book.author}
                </p>
                <p className="mt-2">{book.description}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
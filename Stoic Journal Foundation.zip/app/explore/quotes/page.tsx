import { Card } from "@/components/ui/card";
import { Quote } from "lucide-react";

const quotes = [
  {
    text: "Waste no more time arguing what a good man should be. Be one.",
    author: "Marcus Aurelius",
    source: "Meditations"
  },
  {
    text: "The happiness of your life depends upon the quality of your thoughts.",
    author: "Marcus Aurelius",
    source: "Meditations"
  },
  {
    text: "He who fears death will never do anything worthy of a man who is alive.",
    author: "Seneca",
    source: "Moral Letters"
  }
];

export default function QuotesPage() {
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Daily Quotes</h1>
        <p className="text-muted-foreground mt-1">
          Wisdom from Stoic philosophers to inspire your practice
        </p>
      </div>

      <div className="space-y-4">
        {quotes.map((quote, index) => (
          <Card key={index} className="p-6">
            <div className="flex gap-4">
              <Quote className="h-6 w-6 text-primary shrink-0" />
              <div>
                <blockquote className="text-lg font-medium">
                  "{quote.text}"
                </blockquote>
                <footer className="text-sm text-muted-foreground mt-2">
                  — {quote.author}, {quote.source}
                </footer>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
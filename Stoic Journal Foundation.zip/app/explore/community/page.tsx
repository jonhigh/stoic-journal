import { Card } from "@/components/ui/card";
import { Users, MessageSquare } from "lucide-react";

export default function CommunityPage() {
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Community</h1>
        <p className="text-muted-foreground mt-1">
          Connect with fellow practitioners of Stoic philosophy
        </p>
      </div>

      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <Users className="h-5 w-5 text-primary" />
          <h2 className="text-xl font-semibold">Coming Soon</h2>
        </div>
        <p className="text-muted-foreground">
          We're working on building a community space where you can connect with others,
          share experiences, and discuss Stoic philosophy. Check back soon!
        </p>
      </Card>

      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <MessageSquare className="h-5 w-5 text-primary" />
          <h2 className="text-xl font-semibold">Discussion Guidelines</h2>
        </div>
        <ul className="space-y-2 text-muted-foreground">
          <li>• Practice respectful dialogue</li>
          <li>• Share experiences and insights</li>
          <li>• Focus on practical application</li>
          <li>• Support fellow practitioners</li>
        </ul>
      </Card>
    </div>
  );
}
import { Card } from "@/components/ui/card";
import { Compass, BookOpen, Quote, Users } from "lucide-react";
import Link from "next/link";

export default function ExplorePage() {
  const sections = [
    {
      title: "Daily Quotes",
      description: "Discover wisdom from Stoic philosophers",
      icon: Quote,
      href: "/explore/quotes"
    },
    {
      title: "Reading List",
      description: "Essential Stoic texts and modern interpretations",
      icon: BookOpen,
      href: "/explore/reading"
    },
    {
      title: "Community",
      description: "Connect with fellow practitioners",
      icon: Users,
      href: "/explore/community"
    }
  ];

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Explore</h1>
        <p className="text-muted-foreground mt-1">
          Discover resources and connect with the community
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {sections.map((section) => {
          const Icon = section.icon;
          return (
            <Card key={section.title} className="p-6 hover:bg-muted/50 transition-colors">
              <Link href={section.href} className="space-y-3">
                <div className="flex items-center gap-2">
                  <Icon className="h-5 w-5 text-primary" />
                  <h2 className="text-xl font-semibold">{section.title}</h2>
                </div>
                <p className="text-sm text-muted-foreground">
                  {section.description}
                </p>
              </Link>
            </Card>
          );
        })}
      </div>

      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <Compass className="h-5 w-5 text-primary" />
          <h2 className="text-xl font-semibold">Featured Content</h2>
        </div>
        <p className="text-muted-foreground">
          Coming soon! We're working on bringing you curated content and resources.
        </p>
      </Card>
    </div>
  );
}
import { DailyQuote } from "@/components/daily-quote";
import { StatsOverview } from "@/components/stats-overview";
import { JournalPrompts } from "@/components/journal-prompts";
import { DailyFocus } from "@/components/daily-focus";
import { WeeklyGoals } from "@/components/weekly-goals";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BookMarked } from "lucide-react";
import Link from "next/link";

export default function Home() {
  return (
    <div className="max-w-5xl mx-auto space-y-8 py-8">
      <DailyQuote />
      
      <StatsOverview />
      
      <JournalPrompts />
      
      <section className="grid md:grid-cols-2 gap-6">
        <DailyFocus />
        <WeeklyGoals />
      </section>

      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-4">Recent Entries</h2>
        <div className="text-center py-8">
          <BookMarked className="h-12 w-12 mx-auto text-muted-foreground" />
          <p className="text-muted-foreground mt-4">
            No entries yet. Start journaling to see your entries here.
          </p>
          <Button className="mt-4" variant="outline" asChild>
            <Link href="/entries">View All Entries</Link>
          </Button>
        </div>
      </Card>
    </div>
  );
}
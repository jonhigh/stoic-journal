"use client";

import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { JournalEditor } from "@/components/journal-editor";
import { EveningPromptSidebar } from "@/components/evening-prompt-sidebar";
import { ArrowLeft, Save } from "lucide-react";
import Link from "next/link";

export default function EveningJournal() {
  const [content, setContent] = useState("");

  const handleSave = () => {
    // TODO: Implement save functionality
    console.log("Saving journal entry:", content);
  };

  const handlePromptClick = (prompt: string) => {
    setContent((current) => {
      const prefix = current ? current + "\n\n" : "";
      return `${prefix}${prompt}\n`;
    });
  };

  return (
    <div className="h-[calc(100vh-5rem)]">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/">
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Evening Review</h1>
            <p className="text-sm text-muted-foreground">
              {new Date().toLocaleDateString("en-US", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </p>
          </div>
        </div>
        <Button onClick={handleSave}>
          <Save className="mr-2 h-4 w-4" /> Save Entry
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-[1fr,320px] h-[calc(100%-4rem)] gap-6">
        <Card className="p-6">
          <JournalEditor content={content} onChange={setContent} />
        </Card>
        <div className="hidden md:block">
          <EveningPromptSidebar onPromptClick={handlePromptClick} />
        </div>
      </div>
    </div>
  );
}
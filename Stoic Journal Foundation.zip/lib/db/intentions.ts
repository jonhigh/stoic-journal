export interface Intention {
  id: string;
  text: string;
  weekStart: Date;
  weekEnd: Date;
  createdAt: Date;
  updatedAt: Date;
}
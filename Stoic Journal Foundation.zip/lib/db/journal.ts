export interface JournalEntry {
  id: string;
  content: string;
  type: 'morning' | 'evening';
  createdAt: Date;
  updatedAt: Date;
}
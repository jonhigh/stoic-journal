export interface Priority {
  id: string;
  text: string;
  completed: boolean;
  date: Date;
  createdAt: Date;
  updatedAt: Date;
}
export interface Habit {
  id: string;
  text: string;
  completed: boolean;
  date: Date;
  createdAt: Date;
  updatedAt: Date;
}